import { Link, NavLink, useNavigate } from "react-router-dom";
import { FiBookOpen, FiMenu, FiX } from "react-icons/fi";
import { useState } from "react";

const Navbar = () => {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const token = localStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user") || "null");

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setOpen(false);
    navigate("/login");
  };

  const linkClass = ({ isActive }) =>
    `nav-link ${isActive ? "active" : ""}`;

  return (
    <header className="site-header">
      <div className="container nav-wrap">
        <Link to="/" className="brand" onClick={() => setOpen(false)}>
          <span className="brand-icon"><FiBookOpen /></span>
          <span>E-Learning</span>
        </Link>

        <button className="mobile-toggle" onClick={() => setOpen(!open)} aria-label="Toggle menu">
          {open ? <FiX /> : <FiMenu />}
        </button>

        <nav className={`nav-menu ${open ? "open" : ""}`}>
          <NavLink to="/" className={linkClass} onClick={() => setOpen(false)}>Home</NavLink>
          <NavLink to="/about" className={linkClass} onClick={() => setOpen(false)}>About</NavLink>
          <NavLink to="/courses" className={linkClass} onClick={() => setOpen(false)}>Courses</NavLink>

          {token && user?.role === "student" && (
            <NavLink to="/student/dashboard" className={linkClass} onClick={() => setOpen(false)}>Dashboard</NavLink>
          )}

          {token && user?.role === "instructor" && (
            <NavLink to="/instructor/dashboard" className={linkClass} onClick={() => setOpen(false)}>Dashboard</NavLink>
          )}

          <div className="nav-actions">
            {token ? (
              <>
                <span className="user-name">{user?.name}</span>
                <button className="btn btn-primary btn-small" onClick={logout}>Logout</button>
              </>
            ) : (
              <>
                <Link to="/login" className="login-link" onClick={() => setOpen(false)}>Login</Link>
                <Link to="/register" className="btn btn-primary btn-small" onClick={() => setOpen(false)}>Get Started</Link>
              </>
            )}
          </div>
        </nav>
      </div>
    </header>
  );
};
export default Navbar;
