import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FiArrowRight, FiCheckCircle, FiPlayCircle, FiUsers, FiAward, FiBookOpen } from "react-icons/fi";
import { getCourses } from "../services/CourseService";

const categories = [
  ["Web Development", "Build modern websites and full-stack applications.", "01"],
  ["Digital Marketing", "Learn content, SEO, social media and strategy.", "02"],
  ["Graphic Design", "Turn ideas into beautiful visual experiences.", "03"],
  ["Freelancing", "Learn how to start and grow your freelance career.", "04"]
];

const Home = () => {
  const [courses, setCourses] = useState([]);
  useEffect(() => {
    getCourses().then(data => setCourses(data.courses || [])).catch(() => setCourses([]));
  }, []);

  return (
    <>
      <section className="hero-section">
        <div className="hero-shape hero-shape-one" />
        <div className="hero-shape hero-shape-two" />
        <div className="container hero-grid">
          <div className="hero-content">
            <span className="eyebrow"><FiPlayCircle /> LEARN WITHOUT LIMITS</span>
            <h1>Learn skills today.<br /><span>Shape your future.</span></h1>
            <p>Access practical, engaging courses designed to help students and professionals learn faster, grow their skills and achieve their goals.</p>
            <div className="hero-buttons">
              <Link to="/courses" className="btn btn-primary">Explore Courses <FiArrowRight /></Link>
              <Link to="/about" className="btn btn-outline">Discover More</Link>
            </div>
            <div className="hero-trust"><FiCheckCircle /> Learn at your own pace &nbsp; <FiCheckCircle /> Practical lessons</div>
          </div>
          <div className="hero-visual">
            <div className="hero-card main-card">
              <div className="hero-card-icon"><FiBookOpen /></div>
              <span>Start Learning</span>
              <strong>Build skills that matter.</strong>
              <div className="mini-progress"><i /></div>
              <small>Course progress <b>72%</b></small>
            </div>
            <div className="floating-card"><FiUsers /><b>10K+</b><span>Happy learners</span></div>
            <div className="floating-card second"><FiAward /><b>50+</b><span>Expert courses</span></div>
          </div>
        </div>
      </section>

      <section className="stats-strip">
        <div className="container stats-grid">
          <div><FiUsers /><div><b>10,000+</b><span>Active Learners</span></div></div>
          <div><FiBookOpen /><div><b>50+</b><span>Quality Courses</span></div></div>
          <div><FiAward /><div><b>25+</b><span>Expert Instructors</span></div></div>
          <div><FiCheckCircle /><div><b>100%</b><span>Learn at Your Pace</span></div></div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-heading center">
            <span className="eyebrow">WHAT WE OFFER</span>
            <h2>Explore Our Categories</h2>
            <p>Choose a category and start learning the skills you need for your next step.</p>
          </div>
          <div className="category-grid">
            {categories.map(([title, text, number]) => (
              <Link to="/courses" className="category-card" key={title}>
                <span className="category-number">{number}</span>
                <h3>{title}</h3><p>{text}</p><span className="read-link">Explore <FiArrowRight /></span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="section section-soft">
        <div className="container">
          <div className="section-heading row-heading">
            <div><span className="eyebrow">POPULAR COURSES</span><h2>Learn from the best</h2></div>
            <Link to="/courses" className="text-link">View all courses <FiArrowRight /></Link>
          </div>
          <div className="course-grid">
            {courses.slice(0, 6).map(course => (
              <Link to={`/courses/${course._id}`} className="course-card" key={course._id}>
                <div className="course-image">{course.thumbnail ? <img src={course.thumbnail} alt={course.title} /> : <div className="course-placeholder"><FiBookOpen /></div>}</div>
                <div className="course-body">
                  <span className="course-tag">{course.category || "Course"}</span>
                  <h3>{course.title}</h3><p>{course.description}</p>
                  <div className="course-meta"><span>★ {course.averageRating || 0}</span><b>{course.price === 0 ? "Free" : `Rs. ${course.price}`}</b></div>
                </div>
              </Link>
            ))}
          </div>
          {courses.length === 0 && <div className="empty-state">Courses will appear here when they are added.</div>}
        </div>
      </section>

      <section className="about-home">
        <div className="container split-grid">
          <div className="about-visual"><div className="about-photo"><FiBookOpen /></div><div className="experience-badge"><b>Learn</b><span>Every day</span></div></div>
          <div className="about-copy"><span className="eyebrow">ABOUT US</span><h2>A better way to learn, grow and move forward.</h2><p>Our platform makes quality education accessible through structured courses, practical lessons and a simple learning experience.</p><ul><li><FiCheckCircle /> Learn from structured lessons</li><li><FiCheckCircle /> Track your course progress</li><li><FiCheckCircle /> Learn anywhere, anytime</li></ul><Link to="/about" className="btn btn-primary">Learn More <FiArrowRight /></Link></div>
        </div>
      </section>
    </>
  );
};
export default Home;
