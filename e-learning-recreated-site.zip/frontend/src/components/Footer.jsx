import { Link } from "react-router-dom";
import { FiBookOpen, FiMail, FiMapPin, FiPhone } from "react-icons/fi";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <Link to="/" className="brand footer-brand"><span className="brand-icon"><FiBookOpen /></span>E-Learning</Link>
          <p className="footer-text">Learn practical skills from anywhere and build a future you are proud of.</p>
        </div>
        <div>
          <h4>Quick Links</h4>
          <Link to="/about">About Us</Link>
          <Link to="/courses">Courses</Link>
          <Link to="/login">Login</Link>
          <Link to="/register">Register</Link>
        </div>
        <div>
          <h4>Categories</h4>
          <span>Web Development</span>
          <span>Digital Marketing</span>
          <span>Graphic Design</span>
          <span>Freelancing</span>
        </div>
        <div>
          <h4>Contact</h4>
          <span><FiMail /> hello@elearning.com</span>
          <span><FiPhone /> +977 9800000000</span>
          <span><FiMapPin /> Kathmandu, Nepal</span>
        </div>
      </div>
      <div className="footer-bottom"><div className="container">© {new Date().getFullYear()} E-Learning. All rights reserved.</div></div>
    </footer>
  );
}
