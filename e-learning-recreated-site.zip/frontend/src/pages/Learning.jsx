import { useEffect, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";

import { getCourseById } from "../services/CourseService";

import {
    getSectionsByCourse,
    getLessonsBySection
} from "../services/Contentservice";

import {
    completeLesson,
    getCourseProgress
} from "../services/ProgressService";

const getYouTubeEmbedUrl = (url) => {
    if (!url) return "";

    if (url.includes("/embed/")) {
        return url;
    }

    if (url.includes("youtu.be/")) {
        const videoId = url.split("youtu.be/")[1].split("?")[0];
        return `https://www.youtube.com/embed/${videoId}`;
    }

    if (url.includes("watch?v=")) {
        const videoId = url.split("watch?v=")[1].split("&")[0];
        return `https://www.youtube.com/embed/${videoId}`;
    }

    return url;
};

const Learning = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();

    const lessonId = searchParams.get("lesson");

    const [course, setCourse] = useState(null);
    const [sections, setSections] = useState([]);
    const [selectedLesson, setSelectedLesson] = useState(null);

    const [progress, setProgress] = useState(0);
    const [completedLessons, setCompletedLessons] = useState([]);

    const [loading, setLoading] = useState(true);
    const [enrolled, setEnrolled] = useState(false);

    const token = localStorage.getItem("token");
    const user = JSON.parse(localStorage.getItem("user"));

    useEffect(() => {
        const fetchData = async () => {
            try {
                const courseData = await getCourseById(id);
                setCourse(courseData.course);

                const sectionData = await getSectionsByCourse(id);

                const sectionsWithLessons = await Promise.all(
                    sectionData.sections.map(async (section) => {
                        const lessonData =
                            await getLessonsBySection(section._id);

                        return {
                            ...section,
                            lessons: lessonData.lessons
                        };
                    })
                );

                setSections(sectionsWithLessons);

                const allLessons = sectionsWithLessons.flatMap(
                    (section) => section.lessons || []
                );

                if (token) {
                    try {
                        const progressData =
                            await getCourseProgress(id, token);

                        setProgress(progressData.progress || 0);

                        setCompletedLessons(
                            progressData.completedLessons || []
                        );
                    } catch (error) {
                        console.log(
                            "Progress not available:",
                            error.response?.data || error.message
                        );
                    }

                    try {
                        const enrollmentResponse =
                            await fetch(
                                `${import.meta.env.VITE_API_URL}/enrollments/my`,
                                {
                                    headers: {
                                        Authorization: `Bearer ${token}`
                                    }
                                }
                            );

                        const enrollmentData =
                            await enrollmentResponse.json();

                        const isEnrolled =
                            enrollmentData.enrollments?.some(
                                (enrollment) =>
                                    enrollment.course?._id === id
                            );

                        setEnrolled(isEnrolled);
                    } catch (error) {
                        console.log(
                            "Enrollment check failed:",
                            error.message
                        );
                    }
                }

                if (lessonId) {
                    const selected = allLessons.find(
                        (lesson) => lesson._id === lessonId
                    );

                    if (selected) {
                        setSelectedLesson(selected);
                    }
                } else if (allLessons.length > 0) {
                    const firstFreeLesson =
                        allLessons.find(
                            (lesson) => lesson.isFree
                        );

                    setSelectedLesson(
                        firstFreeLesson || allLessons[0]
                    );
                }
            } catch (error) {
                console.log(
                    "LEARNING ERROR:",
                    error.response?.data || error.message
                );
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [id, token, lessonId]);

    const canWatchLesson = (lesson) => {
        if (!lesson) {
            return false;
        }

        if (lesson.isFree) {
            return true;
        }

        if (user?.role === "instructor") {
            return true;
        }

        if (enrolled) {
            return true;
        }

        return false;
    };

    const handleLessonClick = (lesson) => {
        if (!canWatchLesson(lesson)) {
            alert("Please enroll in this course to watch this lesson.");
            return;
        }

        setSelectedLesson(lesson);

        navigate(
            `/courses/${id}/learn?lesson=${lesson._id}`,
            { replace: true }
        );
    };

    const handleComplete = async () => {
        if (!selectedLesson || !token) {
            return;
        }

        try {
            const data = await completeLesson(
                selectedLesson._id,
                id,
                token
            );

            alert(data.message);

            setProgress(data.progress);

            if (!completedLessons.includes(selectedLesson._id)) {
                setCompletedLessons([
                    ...completedLessons,
                    selectedLesson._id
                ]);
            }
        } catch (error) {
            alert(
                error.response?.data?.message ||
                "Failed to update progress"
            );
        }
    };

    const isLessonCompleted = (lessonId) => {
        return completedLessons.some(
            (id) =>
                id.toString() === lessonId.toString()
        );
    };

    if (loading) {
        return (
            <div className="flex min-h-screen items-center justify-center">
                <p className="text-gray-600">
                    Loading lesson...
                </p>
            </div>
        );
    }

    if (!course) {
        return (
            <div className="flex min-h-screen items-center justify-center">
                <p className="text-red-500">
                    Course not found
                </p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-100">

            <div className="border-b bg-white px-4 py-4">
                <div className="mx-auto max-w-7xl">

                    <h1 className="text-xl font-bold text-gray-900">
                        {course.title}
                    </h1>

                    <div className="mt-3 flex items-center gap-3">

                        <div className="h-2 flex-1 overflow-hidden rounded-full bg-gray-200">
                            <div
                                className="h-full rounded-full bg-blue-600"
                                style={{
                                    width: `${progress}%`
                                }}
                            ></div>
                        </div>

                        <span className="text-sm font-medium text-gray-700">
                            {progress}%
                        </span>

                    </div>

                </div>
            </div>

            <div className="mx-auto grid max-w-7xl grid-cols-1 lg:grid-cols-3">

                <div className="order-2 border-r bg-white lg:order-1 lg:col-span-1">

                    <div className="border-b p-5">

                        <h2 className="text-lg font-bold text-gray-900">
                            Course Content
                        </h2>

                    </div>

                    <div className="max-h-[calc(100vh-120px)] overflow-y-auto">

                        {sections.map(
                            (section, sectionIndex) => (
                                <div
                                    key={section._id}
                                    className="border-b"
                                >

                                    <div className="bg-gray-50 px-5 py-4">

                                        <h3 className="font-semibold text-gray-900">
                                            {sectionIndex + 1}.{" "}
                                            {section.title}
                                        </h3>

                                    </div>

                                    {section.lessons?.map(
                                        (
                                            lesson,
                                            lessonIndex
                                        ) => {

                                            const completed =
                                                isLessonCompleted(
                                                    lesson._id
                                                );

                                            const selected =
                                                selectedLesson?._id ===
                                                lesson._id;

                                            const watchable =
                                                canWatchLesson(
                                                    lesson
                                                );

                                            return (
                                                <button
                                                    key={
                                                        lesson._id
                                                    }
                                                    onClick={() =>
                                                        handleLessonClick(
                                                            lesson
                                                        )
                                                    }
                                                    className={`flex w-full items-center justify-between px-5 py-4 text-left transition ${
                                                        selected
                                                            ? "bg-blue-50"
                                                            : "hover:bg-gray-50"
                                                    }`}
                                                >

                                                    <div className="flex items-start gap-3">

                                                        <span
                                                            className={`mt-0.5 flex h-6 w-6 items-center justify-center rounded-full text-xs ${
                                                                completed
                                                                    ? "bg-green-600 text-white"
                                                                    : watchable
                                                                    ? "bg-gray-200 text-gray-600"
                                                                    : "bg-gray-300 text-gray-500"
                                                            }`}
                                                        >
                                                            {completed
                                                                ? "✓"
                                                                : lessonIndex +
                                                                  1}
                                                        </span>

                                                        <div>

                                                            <p className="text-sm font-medium text-gray-800">
                                                                {
                                                                    lesson.title
                                                                }
                                                            </p>

                                                            {lesson.duration && (
                                                                <p className="mt-1 text-xs text-gray-400">
                                                                    {
                                                                        lesson.duration
                                                                    }
                                                                </p>
                                                            )}

                                                        </div>

                                                    </div>

                                                    <span className="text-xs">

                                                        {lesson.isFree ? (
                                                            <span className="text-green-600">
                                                                Free
                                                            </span>
                                                        ) : watchable ? (
                                                            <span className="text-blue-600">
                                                                Watch
                                                            </span>
                                                        ) : (
                                                            <span className="text-gray-400">
                                                                Locked
                                                            </span>
                                                        )}

                                                    </span>

                                                </button>
                                            );
                                        }
                                    )}

                                </div>
                            )
                        )}

                    </div>

                </div>

                <div className="order-1 lg:order-2 lg:col-span-2">

                    {selectedLesson ? (

                        <div className="p-5 sm:p-8">

                            {canWatchLesson(selectedLesson) ? (

                                <>
                                    <div className="overflow-hidden rounded-xl bg-black">

                                        {selectedLesson.videoUrl ? (
                                            <iframe
                                                className="aspect-video w-full"
                                                src={getYouTubeEmbedUrl(
                                                    selectedLesson.videoUrl
                                                )}
                                                title={
                                                    selectedLesson.title
                                                }
                                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                allowFullScreen
                                            ></iframe>
                                        ) : (
                                            <div className="flex aspect-video items-center justify-center text-white">
                                                No video available
                                            </div>
                                        )}

                                    </div>

                                    <div className="mt-6 rounded-xl bg-white p-6 shadow-sm">

                                        <h2 className="text-2xl font-bold text-gray-900">
                                            {
                                                selectedLesson.title
                                            }
                                        </h2>

                                        <p className="mt-4 leading-7 text-gray-600">
                                            {selectedLesson.description ||
                                                "No description available."}
                                        </p>

                                        <div className="mt-6 border-t pt-5">

                                            {isLessonCompleted(
                                                selectedLesson._id
                                            ) ? (

                                                <div className="rounded-lg bg-green-50 p-4 text-green-700">
                                                    Lesson completed
                                                </div>

                                            ) : token ? (

                                                <button
                                                    onClick={
                                                        handleComplete
                                                    }
                                                    className="rounded-lg bg-blue-600 px-6 py-3 font-medium text-white hover:bg-blue-700"
                                                >
                                                    Mark as Complete
                                                </button>

                                            ) : (

                                                <button
                                                    onClick={() =>
                                                        navigate(
                                                            "/login"
                                                        )
                                                    }
                                                    className="rounded-lg bg-blue-600 px-6 py-3 font-medium text-white hover:bg-blue-700"
                                                >
                                                    Login to Track Progress
                                                </button>

                                            )}

                                        </div>

                                    </div>
                                </>

                            ) : (

                                <div className="flex min-h-125 items-center justify-center rounded-xl bg-white p-8 text-center shadow-sm">

                                    <div>

                                        <div className="mb-4 text-4xl">
                                            🔒
                                        </div>

                                        <h2 className="text-2xl font-bold text-gray-900">
                                            Lesson Locked
                                        </h2>

                                        <p className="mt-3 text-gray-500">
                                            Enroll in this course to watch this lesson.
                                        </p>

                                        <button
                                            onClick={() =>
                                                navigate(
                                                    `/courses/${id}`
                                                )
                                            }
                                            className="mt-6 rounded-lg bg-blue-600 px-6 py-3 font-medium text-white hover:bg-blue-700"
                                        >
                                            View Course
                                        </button>

                                    </div>

                                </div>

                            )}

                        </div>

                    ) : (

                        <div className="flex min-h-125 items-center justify-center">

                            <p className="text-gray-500">
                                Select a lesson to start learning.
                            </p>

                        </div>

                    )}

                </div>

            </div>

        </div>
    );
};

export default Learning;