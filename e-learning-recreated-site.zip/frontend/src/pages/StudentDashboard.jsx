import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getStudentDashboard } from "../services/StudentService";

const StudentDashboard = () => {
    const navigate = useNavigate();

    const [dashboard, setDashboard] = useState(null);
    const [loading, setLoading] = useState(true);

    const token = localStorage.getItem("token");

    useEffect(() => {
        const fetchDashboard = async () => {
            try {
                const data = await getStudentDashboard(token);
                setDashboard(data.dashboard);
            } catch (error) {
                console.log(
                    error.response?.data || error.message
                );
            } finally {
                setLoading(false);
            }
        };

        fetchDashboard();
    }, [token]);

    if (loading) {
        return (
            <div className="flex min-h-screen items-center justify-center">
                <p className="text-gray-600">
                    Loading dashboard...
                </p>
            </div>
        );
    }

    if (!dashboard) {
        return (
            <div className="flex min-h-screen items-center justify-center">
                <p className="text-red-500">
                    Failed to load dashboard
                </p>
            </div>
        );
    }

    const validCourses = dashboard.courses.filter(
        (item) => item.course
    );

    return (
        <div className="min-h-screen bg-gray-50 px-4 py-8 sm:px-6 lg:px-10">
            <div className="mx-auto max-w-7xl">

                <h1 className="mb-8 text-3xl font-bold text-gray-900">
                    Student Dashboard
                </h1>

                <div className="mb-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">

                    <div className="rounded-xl bg-white p-6 shadow-sm">
                        <p className="text-sm text-gray-500">
                            Total Courses
                        </p>

                        <h2 className="mt-2 text-3xl font-bold text-gray-900">
                            {dashboard.totalCourses}
                        </h2>
                    </div>

                    <div className="rounded-xl bg-white p-6 shadow-sm">
                        <p className="text-sm text-gray-500">
                            Learning
                        </p>

                        <h2 className="mt-2 text-3xl font-bold text-gray-900">
                            {dashboard.learningCourses}
                        </h2>
                    </div>

                    <div className="rounded-xl bg-white p-6 shadow-sm">
                        <p className="text-sm text-gray-500">
                            Completed
                        </p>

                        <h2 className="mt-2 text-3xl font-bold text-gray-900">
                            {dashboard.completedCourses}
                        </h2>
                    </div>

                    <div className="rounded-xl bg-white p-6 shadow-sm">
                        <p className="text-sm text-gray-500">
                            Overall Progress
                        </p>

                        <h2 className="mt-2 text-3xl font-bold text-gray-900">
                            {dashboard.overallProgress}%
                        </h2>
                    </div>

                </div>

                <h2 className="mb-5 text-2xl font-bold text-gray-900">
                    My Courses
                </h2>

                {validCourses.length === 0 ? (
                    <div className="rounded-xl bg-white p-8 text-center shadow-sm">
                        <p className="text-gray-500">
                            You haven't enrolled in any courses yet.
                        </p>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">

                        {validCourses.map((item) => (
                            <div
                                key={item.enrollmentId}
                                className="overflow-hidden rounded-xl bg-white shadow-sm"
                            >

                                <div className="h-40 bg-gray-200">

                                    {item.course.thumbnail ? (
                                        <img
                                            src={item.course.thumbnail}
                                            alt={item.course.title}
                                            className="h-full w-full object-cover"
                                        />
                                    ) : (
                                        <div className="flex h-full items-center justify-center text-gray-400">
                                            No Image
                                        </div>
                                    )}

                                </div>

                                <div className="p-5">

                                    <p className="mb-2 text-sm text-gray-500">
                                        {item.course.category}
                                    </p>

                                    <h3 className="mb-4 text-xl font-semibold text-gray-900">
                                        {item.course.title}
                                    </h3>

                                    <div className="mb-2 flex justify-between text-sm">

                                        <span className="text-gray-500">
                                            Progress
                                        </span>

                                        <span className="font-medium text-gray-900">
                                            {item.progress}%
                                        </span>

                                    </div>

                                    <div className="h-2 overflow-hidden rounded-full bg-gray-200">

                                        <div
                                            className="h-full rounded-full bg-blue-600"
                                            style={{
                                                width: `${item.progress}%`
                                            }}
                                        ></div>

                                    </div>

                                    <p className="mt-3 text-sm text-gray-500">
                                        {item.completedLessons} lessons completed
                                    </p>

                                    <button
                                        onClick={() =>
                                            navigate(
                                                `/courses/${item.course._id}/learn`
                                            )
                                        }
                                        className="mt-5 w-full rounded-lg bg-blue-600 px-4 py-3 font-medium text-white hover:bg-blue-700"
                                    >
                                        Continue Learning
                                    </button>

                                </div>

                            </div>
                        ))}

                    </div>
                )}

            </div>
        </div>
    );
};

export default StudentDashboard;