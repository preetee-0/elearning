import { Link } from "react-router-dom";
import { FiArrowRight, FiBookOpen, FiCheckCircle, FiTarget, FiUsers, FiAward } from "react-icons/fi";

export default function About() {
  return (
    <>
      <section className="page-hero"><div className="container"><span className="eyebrow">ABOUT US</span><h1>Empowering people through <span>better learning.</span></h1><p>We make practical education simple, accessible and engaging for everyone.</p></div></section>
      <section className="section"><div className="container split-grid">
        <div className="about-visual large"><div className="about-photo"><FiBookOpen /></div><div className="experience-badge"><b>Learn</b><span>Without limits</span></div></div>
        <div className="about-copy"><span className="eyebrow">WHO WE ARE</span><h2>Education should open doors, not create barriers.</h2><p>E-Learning is a modern learning platform created to connect learners with useful skills through clear courses, organized lessons and progress tracking.</p><p>Whether you are starting from zero or improving an existing skill, our learning experience helps you move step by step.</p><ul><li><FiCheckCircle /> Practical and structured learning</li><li><FiCheckCircle /> Beginner-friendly lessons</li><li><FiCheckCircle /> Flexible learning at your pace</li></ul></div>
      </div></section>
      <section className="section section-soft"><div className="container"><div className="section-heading center"><span className="eyebrow">OUR VALUES</span><h2>What guides us</h2></div><div className="value-grid"><div className="value-card"><FiTarget/><h3>Our Mission</h3><p>Make useful education accessible and help learners develop skills they can apply in the real world.</p></div><div className="value-card"><FiUsers/><h3>Our Community</h3><p>Create a welcoming learning environment where students can learn, practice and grow.</p></div><div className="value-card"><FiAward/><h3>Our Focus</h3><p>Keep courses practical, organized and focused on outcomes that matter to learners.</p></div></div></div></section>
      <section className="cta-section"><div className="container"><h2>Ready to start learning?</h2><p>Explore our courses and take the next step in your learning journey.</p><Link to="/courses" className="btn btn-light">Explore Courses <FiArrowRight/></Link></div></section>
    </>
  );
}
