import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const InstructorDashboard = () => {
    const navigate = useNavigate();

    const [courses, setCourses] = useState([]);
    const [loading, setLoading] = useState(true);

    const token = localStorage.getItem("token");

    const handleDeleteCourse = async (courseId) => {
    const confirmDelete = window.confirm(
        "Are you sure you want to delete this course?"
    );

    if (!confirmDelete) {
        return;
    }

    try {
        await axios.delete(
            `${import.meta.env.VITE_API_URL}/courses/${courseId}`,
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );

        setCourses(
            courses.filter(
                (course) => course._id !== courseId
            )
        );

        alert("Course deleted successfully");
    } catch (error) {
        console.log(
            error.response?.data || error.message
        );

        alert(
            error.response?.data?.message ||
            "Failed to delete course"
        );
    }
};
    useEffect(() => {
        const fetchCourses = async () => {
            try {
                const response = await axios.get(
                    `${import.meta.env.VITE_API_URL}/courses/my`,
                    {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    }
                );

                setCourses(response.data.courses);
            } catch (error) {
                console.log(
                    error.response?.data || error.message
                );
            } finally {
                setLoading(false);
            }
        };

        fetchCourses();
    }, [token]);

    return (
        <div className="min-h-screen bg-gray-100 px-4 py-10">
            <div className="mx-auto max-w-6xl">
                <div className="mb-8 flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">
                            Instructor Dashboard
                        </h1>

                        <p className="mt-2 text-gray-500">
                            Create and manage your courses.
                        </p>
                    </div>

                    <button
                        onClick={() =>
                            navigate("/instructor/create-course")
                        }
                        className="rounded-lg bg-blue-600 px-5 py-3 font-medium text-white hover:bg-blue-700"
                    >
                        + Create Course
                    </button>
                </div>

                <div className="mb-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
                    <div className="rounded-xl bg-white p-6 shadow-sm">
                        <p className="text-sm text-gray-500">
                            Total Courses
                        </p>

                        <h2 className="mt-2 text-3xl font-bold text-gray-900">
                            {courses.length}
                        </h2>
                    </div>

                    <div className="rounded-xl bg-white p-6 shadow-sm">
                        <p className="text-sm text-gray-500">
                            Published Courses
                        </p>

                        <h2 className="mt-2 text-3xl font-bold text-gray-900">
                            {courses.length}
                        </h2>
                    </div>

                    <div className="rounded-xl bg-white p-6 shadow-sm">
                        <p className="text-sm text-gray-500">
                            Students
                        </p>

                        <h2 className="mt-2 text-3xl font-bold text-gray-900">
                            0
                        </h2>
                    </div>
                </div>

                <div className="rounded-xl bg-white p-6 shadow-sm">
                    <div className="mb-6">
                        <h2 className="text-xl font-bold text-gray-900">
                            My Courses
                        </h2>

                        <p className="mt-1 text-sm text-gray-500">
                            Courses created by you.
                        </p>
                    </div>

                    {loading ? (
                        <p className="text-gray-500">
                            Loading courses...
                        </p>
                    ) : courses.length === 0 ? (
                        <div className="rounded-lg bg-gray-50 p-8 text-center">
                            <p className="text-gray-500">
                                You have not created any courses yet.
                            </p>

                            <button
                                onClick={() =>
                                    navigate(
                                        "/instructor/create-course"
                                    )
                                }
                                className="mt-4 rounded-lg bg-blue-600 px-5 py-2 text-white hover:bg-blue-700"
                            >
                                Create Your First Course
                            </button>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                            {courses.map((course) => (
                                <div
                                    key={course._id}
                                    className="overflow-hidden rounded-xl border bg-white"
                                >
                                    <div className="h-40 bg-gray-200">
                                        {course.thumbnail ? (
                                            <img
                                                src={course.thumbnail}
                                                alt={course.title}
                                                className="h-full w-full object-cover"
                                            />
                                        ) : (
                                            <div className="flex h-full items-center justify-center text-gray-400">
                                                No Image
                                            </div>
                                        )}
                                    </div>

                                    <div className="p-5">
                                        <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-medium text-blue-600">
                                            {course.category}
                                        </span>

                                        <h3 className="mt-3 text-lg font-bold text-gray-900">
                                            {course.title}
                                        </h3>

                                        <p className="mt-2 line-clamp-2 text-sm text-gray-500">
                                            {course.description}
                                        </p>

                                        <div className="mt-4 flex items-center justify-between text-sm">
                                            <span className="text-gray-500">
                                                {course.level}
                                            </span>

                                            <span className="font-semibold">
                                                {course.price === 0
                                                    ? "Free"
                                                    : `Rs. ${course.price}`}
                                            </span>
                                        </div>

                                        <div className="mt-5 flex gap-2">
    <button
        onClick={() =>
            navigate(`/courses/${course._id}`)
        }
        className="flex-1 rounded-lg bg-gray-900 px-4 py-2.5 font-medium text-white hover:bg-gray-800"
    >
        View
    </button>

    <button
        onClick={() =>
            navigate(
                `/instructor/edit-course/${course._id}`
            )
        }
        className="flex-1 rounded-lg border border-blue-600 px-4 py-2.5 font-medium text-blue-600 hover:bg-blue-50"
    >
        Edit
    </button>

    <button
        onClick={() =>
            handleDeleteCourse(course._id)
        }
        className="flex-1 rounded-lg border border-red-600 px-4 py-2.5 font-medium text-red-600 hover:bg-red-50"
    >
        Delete
    </button>
</div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default InstructorDashboard;