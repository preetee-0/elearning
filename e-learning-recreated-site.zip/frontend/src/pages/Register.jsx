import { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { FiBookOpen, FiUser, FiMail, FiLock } from "react-icons/fi";

export default function Register() {
  const [name,setName]=useState("");const [email,setEmail]=useState("");const [password,setPassword]=useState("");const navigate=useNavigate();
  const submit=async e=>{e.preventDefault();try{await axios.post(`${import.meta.env.VITE_API_URL}/users/register`,{name,email,password,role:"student"});alert("Registration successful");navigate("/login")}catch(err){alert(err.response?.data?.message||"Registration failed")}};
  return <div className="auth-page"><div className="auth-card"><div className="auth-logo"><FiBookOpen/></div><span className="eyebrow">GET STARTED</span><h1>Create your account</h1><p>Join our learning community and start building new skills.</p><form onSubmit={submit}><label>Name<div className="input-wrap"><FiUser/><input value={name} onChange={e=>setName(e.target.value)} placeholder="Your full name" required/></div></label><label>Email<div className="input-wrap"><FiMail/><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required/></div></label><label>Password<div className="input-wrap"><FiLock/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Create a password" required/></div></label><button className="btn btn-primary full">Create Account</button></form><div className="auth-footer">Already have an account? <Link to="/login">Sign in</Link></div></div></div>
}
