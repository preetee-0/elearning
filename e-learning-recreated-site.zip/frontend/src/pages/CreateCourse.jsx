import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const CreateCourse = () => {
    const navigate = useNavigate();

    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [category, setCategory] = useState("");
    const [price, setPrice] = useState(0);
    const [thumbnail, setThumbnail] = useState("");
    const [level, setLevel] = useState("beginner");
    const [duration, setDuration] = useState("");

    const [sections, setSections] = useState([
        {
            title: "",
            lessons: [
                {
                    title: "",
                    description: "",
                    videoUrl: "",
                    duration: "",
                    isFree: false
                }
            ]
        }
    ]);

    const addSection = () => {
        setSections([
            ...sections,
            {
                title: "",
                lessons: [
                    {
                        title: "",
                        description: "",
                        videoUrl: "",
                        duration: "",
                        isFree: false
                    }
                ]
            }
        ]);
    };

    const removeSection = (sectionIndex) => {
        const updatedSections = sections.filter(
            (_, index) => index !== sectionIndex
        );

        setSections(updatedSections);
    };

    const updateSection = (
        sectionIndex,
        value
    ) => {
        const updatedSections = [...sections];

        updatedSections[sectionIndex].title =
            value;

        setSections(updatedSections);
    };

    const addLesson = (sectionIndex) => {
        const updatedSections = [...sections];

        updatedSections[sectionIndex].lessons.push({
            title: "",
            description: "",
            videoUrl: "",
            duration: "",
            isFree: false
        });

        setSections(updatedSections);
    };

    const removeLesson = (
        sectionIndex,
        lessonIndex
    ) => {
        const updatedSections = [...sections];

        updatedSections[sectionIndex].lessons =
            updatedSections[
                sectionIndex
            ].lessons.filter(
                (_, index) =>
                    index !== lessonIndex
            );

        setSections(updatedSections);
    };

    const updateLesson = (
        sectionIndex,
        lessonIndex,
        field,
        value
    ) => {
        const updatedSections = [...sections];

        updatedSections[
            sectionIndex
        ].lessons[lessonIndex][field] =
            value;

        setSections(updatedSections);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const token =
            localStorage.getItem("token");

        try {
            const courseResponse =
                await axios.post(
                    `${import.meta.env.VITE_API_URL}/courses`,
                    {
                        title,
                        description,
                        category,
                        price: Number(price),
                        thumbnail,
                        level,
                        duration
                    },
                    {
                        headers: {
                            Authorization:
                                `Bearer ${token}`
                        }
                    }
                );

            const courseId =
                courseResponse.data.course._id;

            for (
                let i = 0;
                i < sections.length;
                i++
            ) {
                const sectionResponse =
                    await axios.post(
                        `${import.meta.env.VITE_API_URL}/sections`,
                        {
                            title:
                                sections[i].title,
                            course: courseId,
                            order: i + 1
                        },
                        {
                            headers: {
                                Authorization:
                                    `Bearer ${token}`
                            }
                        }
                    );

                const sectionId =
                    sectionResponse.data.section._id;

                for (
                    let j = 0;
                    j <
                    sections[i].lessons.length;
                    j++
                ) {
                    const lesson =
                        sections[i].lessons[j];

                    await axios.post(
                        `${import.meta.env.VITE_API_URL}/lessons`,
                        {
                            title:
                                lesson.title,
                            description:
                                lesson.description,
                            section:
                                sectionId,
                            videoUrl:
                                lesson.videoUrl,
                            duration:
                                lesson.duration,
                            order: j + 1,
                            isFree:
                                lesson.isFree
                        },
                        {
                            headers: {
                                Authorization:
                                    `Bearer ${token}`
                            }
                        }
                    );
                }
            }

            alert(
                "Course created successfully"
            );

            navigate("/courses");
        } catch (error) {
            console.log("CREATE COURSE ERROR:", error);
console.log("ERROR RESPONSE:", error.response?.data);
console.log("ERROR STATUS:", error.response?.status);

            alert(
                error.response?.data?.message ||
                "Failed to create course"
            );
        }
    };

    return (
        <div className="min-h-screen bg-gray-100 px-4 py-10">
            <div className="mx-auto max-w-4xl">

                <h1 className="text-3xl font-bold text-gray-900">
                    Create Course
                </h1>

                <p className="mt-2 text-gray-500">
                    Create your course with sections and lessons.
                </p>

                <form
                    onSubmit={handleSubmit}
                    className="mt-8 space-y-8"
                >

                    <div className="rounded-xl bg-white p-6 shadow-sm">

                        <h2 className="text-xl font-bold">
                            Course Information
                        </h2>

                        <div className="mt-5 space-y-4">

                            <input
                                type="text"
                                placeholder="Course title"
                                value={title}
                                onChange={(e) =>
                                    setTitle(
                                        e.target.value
                                    )
                                }
                                className="w-full rounded-lg border px-4 py-3"
                                required
                            />

                            <textarea
                                placeholder="Course description"
                                value={description}
                                onChange={(e) =>
                                    setDescription(
                                        e.target.value
                                    )
                                }
                                className="w-full rounded-lg border px-4 py-3"
                                rows="4"
                                required
                            />

                            <input
                                type="text"
                                placeholder="Category"
                                value={category}
                                onChange={(e) =>
                                    setCategory(
                                        e.target.value
                                    )
                                }
                                className="w-full rounded-lg border px-4 py-3"
                                required
                            />

                            <input
                                type="number"
                                placeholder="Price"
                                value={price}
                                onChange={(e) =>
                                    setPrice(
                                        e.target.value
                                    )
                                }
                                className="w-full rounded-lg border px-4 py-3"
                            />

                            <input
                                type="text"
                                placeholder="Thumbnail URL"
                                value={thumbnail}
                                onChange={(e) =>
                                    setThumbnail(
                                        e.target.value
                                    )
                                }
                                className="w-full rounded-lg border px-4 py-3"
                            />

                            <select
                                value={level}
                                onChange={(e) =>
                                    setLevel(
                                        e.target.value
                                    )
                                }
                                className="w-full rounded-lg border px-4 py-3"
                            >
                                <option value="beginner">
                                    Beginner
                                </option>

                                <option value="intermediate">
                                    Intermediate
                                </option>

                                <option value="advanced">
                                    Advanced
                                </option>
                            </select>

                            <input
                                type="text"
                                placeholder="Duration e.g. 10 hours"
                                value={duration}
                                onChange={(e) =>
                                    setDuration(
                                        e.target.value
                                    )
                                }
                                className="w-full rounded-lg border px-4 py-3"
                            />

                        </div>
                    </div>

                    {sections.map(
                        (section, sectionIndex) => (
                            <div
                                key={sectionIndex}
                                className="rounded-xl bg-white p-6 shadow-sm"
                            >

                                <div className="flex items-center justify-between">

                                    <h2 className="text-xl font-bold">
                                        Section{" "}
                                        {sectionIndex + 1}
                                    </h2>

                                    {sections.length > 1 && (
                                        <button
                                            type="button"
                                            onClick={() =>
                                                removeSection(
                                                    sectionIndex
                                                )
                                            }
                                            className="text-red-600"
                                        >
                                            Remove Section
                                        </button>
                                    )}

                                </div>

                                <input
                                    type="text"
                                    placeholder="Section title"
                                    value={section.title}
                                    onChange={(e) =>
                                        updateSection(
                                            sectionIndex,
                                            e.target.value
                                        )
                                    }
                                    className="mt-5 w-full rounded-lg border px-4 py-3"
                                    required
                                />

                                <div className="mt-6 space-y-5">

                                    {section.lessons.map(
                                        (
                                            lesson,
                                            lessonIndex
                                        ) => (
                                            <div
                                                key={
                                                    lessonIndex
                                                }
                                                className="rounded-lg border bg-gray-50 p-5"
                                            >

                                                <div className="flex items-center justify-between">

                                                    <h3 className="font-semibold">
                                                        Lesson{" "}
                                                        {lessonIndex +
                                                            1}
                                                    </h3>

                                                    {section
                                                        .lessons
                                                        .length >
                                                        1 && (
                                                        <button
                                                            type="button"
                                                            onClick={() =>
                                                                removeLesson(
                                                                    sectionIndex,
                                                                    lessonIndex
                                                                )
                                                            }
                                                            className="text-sm text-red-600"
                                                        >
                                                            Remove
                                                        </button>
                                                    )}

                                                </div>

                                                <div className="mt-4 space-y-3">

                                                    <input
                                                        type="text"
                                                        placeholder="Lesson title"
                                                        value={
                                                            lesson.title
                                                        }
                                                        onChange={(e) =>
                                                            updateLesson(
                                                                sectionIndex,
                                                                lessonIndex,
                                                                "title",
                                                                e.target.value
                                                            )
                                                        }
                                                        className="w-full rounded-lg border px-4 py-3"
                                                        required
                                                    />

                                                    <textarea
                                                        placeholder="Lesson description"
                                                        value={
                                                            lesson.description
                                                        }
                                                        onChange={(e) =>
                                                            updateLesson(
                                                                sectionIndex,
                                                                lessonIndex,
                                                                "description",
                                                                e.target.value
                                                            )
                                                        }
                                                        className="w-full rounded-lg border px-4 py-3"
                                                        rows="3"
                                                    />

                                                    <input
                                                        type="text"
                                                        placeholder="Video URL"
                                                        value={
                                                            lesson.videoUrl
                                                        }
                                                        onChange={(e) =>
                                                            updateLesson(
                                                                sectionIndex,
                                                                lessonIndex,
                                                                "videoUrl",
                                                                e.target.value
                                                            )
                                                        }
                                                        className="w-full rounded-lg border px-4 py-3"
                                                    />

                                                    <input
                                                        type="text"
                                                        placeholder="Lesson duration e.g. 15 minutes"
                                                        value={
                                                            lesson.duration
                                                        }
                                                        onChange={(e) =>
                                                            updateLesson(
                                                                sectionIndex,
                                                                lessonIndex,
                                                                "duration",
                                                                e.target.value
                                                            )
                                                        }
                                                        className="w-full rounded-lg border px-4 py-3"
                                                    />

                                                    <label className="flex items-center gap-2">

                                                        <input
                                                            type="checkbox"
                                                            checked={
                                                                lesson.isFree
                                                            }
                                                            onChange={(e) =>
                                                                updateLesson(
                                                                    sectionIndex,
                                                                    lessonIndex,
                                                                    "isFree",
                                                                    e.target.checked
                                                                )
                                                            }
                                                        />

                                                        Free preview lesson

                                                    </label>

                                                </div>

                                            </div>
                                        )
                                    )}

                                </div>

                                <button
                                    type="button"
                                    onClick={() =>
                                        addLesson(
                                            sectionIndex
                                        )
                                    }
                                    className="mt-5 rounded-lg bg-gray-800 px-4 py-2 text-white"
                                >
                                    + Add Lesson
                                </button>

                            </div>
                        )
                    )}

                    <button
                        type="button"
                        onClick={addSection}
                        className="rounded-lg bg-blue-600 px-5 py-3 font-medium text-white hover:bg-blue-700"
                    >
                        + Add Section
                    </button>

                    <button
                        type="submit"
                        className="ml-3 rounded-lg bg-green-600 px-6 py-3 font-medium text-white hover:bg-green-700"
                    >
                        Create Course
                    </button>

                </form>

            </div>
        </div>
    );
};

export default CreateCourse;