
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import {
    getCourseById,
    getMyEnrollments,
    enrollCourse
} from "../services/CourseService";

import {
    getSectionsByCourse,
    getLessonsBySection
} from "../services/Contentservice";

const CourseDetails = () => {
    const { id } = useParams();
    const navigate = useNavigate();

    const [course, setCourse] = useState(null);
    const [sections, setSections] = useState([]);
    const [loading, setLoading] = useState(true);
    const [enrolled, setEnrolled] = useState(false);

    const token = localStorage.getItem("token");

    useEffect(() => {
        const fetchData = async () => {
            try {
                const courseData =
                    await getCourseById(id);

                setCourse(courseData.course);

                const sectionData =
                    await getSectionsByCourse(id);

                const sectionsWithLessons =
                    await Promise.all(
                        sectionData.sections.map(
                            async (section) => {
                                const lessonData =
                                    await getLessonsBySection(
                                        section._id
                                    );

                                return {
                                    ...section,
                                    lessons:
                                        lessonData.lessons
                                };
                            }
                        )
                    );

                setSections(sectionsWithLessons);

                if (token) {
                    const enrollmentData =
                        await getMyEnrollments(token);

                    const alreadyEnrolled =
                        enrollmentData.enrollments.some(
                            (enrollment) =>
                                enrollment.course._id === id
                        );

                    setEnrolled(alreadyEnrolled);
                }
            } catch (error) {
                console.log(
                    error.response?.data ||
                    error.message
                );
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [id, token]);

    const handleEnroll = async () => {
        try {
            const data = await enrollCourse(
                id,
                token
            );

            alert(data.message);
            setEnrolled(true);
        } catch (error) {
            alert(
                error.response?.data?.message ||
                "Failed to enroll"
            );
        }
    };

    if (loading) {
        return (
            <div className="flex min-h-screen items-center justify-center">
                <p className="text-gray-600">
                    Loading course...
                </p>
            </div>
        );
    }

    if (!course) {
        return (
            <div className="flex min-h-screen items-center justify-center">
                <p className="text-red-500">
                    Course not found
                </p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 px-4 py-10 sm:px-6 lg:px-10">

            <div className="mx-auto max-w-6xl">

                <button
                    onClick={() =>
                        navigate("/courses")
                    }
                    className="mb-6 text-sm font-medium text-blue-600 hover:text-blue-700"
                >
                    ← Back to Courses
                </button>

                <div className="overflow-hidden rounded-2xl bg-white shadow-sm">

                    <div className="h-64 bg-gray-200 sm:h-80">
                        {course.thumbnail ? (
                            <img
                                src={course.thumbnail}
                                alt={course.title}
                                className="h-full w-full object-cover"
                            />
                        ) : (
                            <div className="flex h-full items-center justify-center text-gray-400">
                                No Image
                            </div>
                        )}
                    </div>

                    <div className="p-6 sm:p-8">

                        <div className="mb-4 flex flex-wrap gap-3">

                            <span className="rounded-full bg-blue-50 px-3 py-1 text-sm font-medium text-blue-600">
                                {course.category}
                            </span>

                            <span className="rounded-full bg-gray-100 px-3 py-1 text-sm text-gray-600">
                                {course.level}
                            </span>

                        </div>

                        <h1 className="mb-4 text-3xl font-bold text-gray-900 sm:text-4xl">
                            {course.title}
                        </h1>

                        <p className="mb-6 leading-7 text-gray-600">
                            {course.description}
                        </p>

                        <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">

                            <div className="rounded-lg bg-gray-50 p-4">
                                <p className="text-sm text-gray-500">
                                    Rating
                                </p>

                                <p className="mt-1 font-semibold">
                                    ★ {course.averageRating || 0}
                                </p>
                            </div>

                            <div className="rounded-lg bg-gray-50 p-4">
                                <p className="text-sm text-gray-500">
                                    Reviews
                                </p>

                                <p className="mt-1 font-semibold">
                                    {course.reviewCount || 0}
                                </p>
                            </div>

                            <div className="rounded-lg bg-gray-50 p-4">
                                <p className="text-sm text-gray-500">
                                    Level
                                </p>

                                <p className="mt-1 font-semibold capitalize">
                                    {course.level}
                                </p>
                            </div>

                            <div className="rounded-lg bg-gray-50 p-4">
                                <p className="text-sm text-gray-500">
                                    Duration
                                </p>

                                <p className="mt-1 font-semibold">
                                    {course.duration ||
                                        "Not specified"}
                                </p>
                            </div>

                        </div>

                        <div className="mb-10 border-t pt-8">

                            <h2 className="mb-5 text-2xl font-bold text-gray-900">
                                Course Content
                            </h2>

                            {sections.length === 0 ? (
                                <div className="rounded-lg bg-gray-50 p-6 text-center">
                                    <p className="text-gray-500">
                                        No course content available yet.
                                    </p>
                                </div>
                            ) : (
                                <div className="space-y-4">

                                    {sections.map(
                                        (section, index) => (
                                            <div
                                                key={section._id}
                                                className="rounded-xl border border-gray-200"
                                            >

                                                <div className="bg-gray-50 p-5">
                                                    <h3 className="text-lg font-semibold text-gray-900">
                                                        {index + 1}.{" "}
                                                        {section.title}
                                                    </h3>

                                                    {section.description && (
                                                        <p className="mt-1 text-sm text-gray-500">
                                                            {
                                                                section.description
                                                            }
                                                        </p>
                                                    )}
                                                </div>

                                                <div className="divide-y">

                                                    {section.lessons
                                                        ?.length > 0 ? (
                                                        section.lessons.map(
                                                            (
                                                                lesson,
                                                                lessonIndex
                                                            ) => (
                                                                <div
                                                                    key={
                                                                        lesson._id
                                                                    }
                                                                    className="flex items-center justify-between px-5 py-4"
                                                                >

                                                                    <div>
                                                                        <p className="font-medium text-gray-800">
                                                                            {lessonIndex +
                                                                                1}.{" "}
                                                                            {
                                                                                lesson.title
                                                                            }
                                                                        </p>

                                                                        {lesson.duration && (
                                                                            <p className="mt-1 text-sm text-gray-500">
                                                                                {
                                                                                    lesson.duration
                                                                                }
                                                                            </p>
                                                                        )}
                                                                    </div>
{lesson.isFree || enrolled ? (
    <button
        onClick={() =>
            navigate(
                `/courses/${id}/learn?lesson=${lesson._id}`
            )
        }
        className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
    >
        {lesson.isFree
            ? "Watch Preview"
            : "Watch Lesson"}
    </button>
) : (
    <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-500">
        Locked
    </span>
)}

                                                                </div>
                                                            )
                                                        )
                                                    ) : (
                                                        <p className="p-5 text-sm text-gray-500">
                                                            No lessons in this section.
                                                        </p>
                                                    )}

                                                </div>

                                            </div>
                                        )
                                    )}

                                </div>
                            )}

                        </div>

                        <div className="flex flex-col gap-4 border-t pt-6 sm:flex-row sm:items-center sm:justify-between">

                            <div>
                                <p className="text-sm text-gray-500">
                                    Course Price
                                </p>

                                <p className="text-2xl font-bold text-gray-900">
                                    {course.price === 0
                                        ? "Free"
                                        : `Rs. ${course.price}`}
                                </p>
                            </div>

                            {enrolled ? (
                                <button
                                    onClick={() =>
                                        navigate(
                                            `/courses/${id}/learn`
                                        )
                                    }
                                    className="rounded-lg bg-green-600 px-8 py-3 font-medium text-white hover:bg-green-700"
                                >
                                    Continue Learning
                                </button>
                            ) : (
                                <button
                                    onClick={handleEnroll}
                                    className="rounded-lg bg-blue-600 px-8 py-3 font-medium text-white hover:bg-blue-700"
                                >
                                    Enroll Now
                                </button>
                            )}

                        </div>

                    </div>
                </div>
            </div>
        </div>
    );
};

export default CourseDetails;
