import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
    getCourses,
    getMyEnrollments,
    enrollCourse
} from "../services/CourseService";

const Courses = () => {
    const [courses, setCourses] = useState([]);
    const [enrolledCourses, setEnrolledCourses] = useState([]);
    const [loading, setLoading] = useState(true);
    

    const token = localStorage.getItem("token");
    
const navigate = useNavigate();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const coursesData = await getCourses();
                setCourses(coursesData.courses);

                if (token) {
                    const enrollmentData =
                        await getMyEnrollments(token);

                    setEnrolledCourses(
    enrollmentData.enrollments.filter(
        (enrollment) => enrollment.course
    )
);
                }
            } catch (error) {
                console.log(
                    error.response?.data || error.message
                );
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [token]);

const isEnrolled = (courseId) => {
    return enrolledCourses.some(
        (enrollment) =>
            enrollment.course &&
            enrollment.course._id === courseId
    );
};

    const handleEnroll = async (courseId) => {
        try {
            const data = await enrollCourse(
                courseId,
                token
            );

            alert(data.message);

            const enrollmentData =
                await getMyEnrollments(token);

            setEnrolledCourses(
                enrollmentData.enrollments
            );
        } catch (error) {
            alert(
                error.response?.data?.message ||
                "Failed to enroll"
            );
        }
    };

    if (loading) {
        return (
            <div className="flex min-h-screen items-center justify-center">
                <p>Loading courses...</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 px-4 py-10 sm:px-6 lg:px-10">
            <div className="mx-auto max-w-7xl">

                <div className="mb-10">
                    <h1 className="text-3xl font-bold text-gray-900">
                        Explore Courses
                    </h1>

                    <p className="mt-2 text-gray-500">
                        Learn new skills and grow your knowledge.
                    </p>
                </div>

                {courses.length === 0 ? (
                    <div className="rounded-xl bg-white p-10 text-center shadow-sm">
                        <p className="text-gray-500">
                            No courses available.
                        </p>
                    </div>
                ) : (
                    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">

                        {courses.map((course) => {
                            const enrolled = isEnrolled(
                                course._id
                            );

                            return (
                                <div
                                    key={course._id}
                                    className="overflow-hidden rounded-xl bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-md"
                                >
                                    <div className="h-48 bg-gray-200">
                                        {course.thumbnail ? (
                                            <img
                                                src={course.thumbnail}
                                                alt={course.title}
                                                className="h-full w-full object-cover"
                                            />
                                        ) : (
                                            <div className="flex h-full items-center justify-center text-gray-400">
                                                No Image
                                            </div>
                                        )}
                                    </div>

                                    <div className="p-5">

                                        <div className="mb-2 flex items-center justify-between">
                                            <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-medium text-blue-600">
                                                {course.category}
                                            </span>

                                            <span className="text-sm text-gray-500">
                                                {course.level}
                                            </span>
                                        </div>

                                        <h2
    onClick={() => navigate(`/courses/${course._id}`)}
    className="mb-2 cursor-pointer text-xl font-semibold text-gray-900 hover:text-blue-600"
>
    {course.title}
</h2>

                                        <p className="mb-4 line-clamp-2 text-sm text-gray-500">
                                            {course.description}
                                        </p>

                                        <div className="mb-4 flex items-center justify-between">

                                            <div>
                                                <span className="text-yellow-500">
                                                    ★
                                                </span>

                                                <span className="ml-1 text-sm font-medium">
                                                    {course.averageRating || 0}
                                                </span>

                                                <span className="ml-1 text-sm text-gray-400">
                                                    ({course.reviewCount || 0})
                                                </span>
                                            </div>

                                            <span className="font-semibold text-gray-900">
                                                {course.price === 0
                                                    ? "Free"
                                                    : `Rs. ${course.price}`}
                                            </span>

                                        </div>

                                        {enrolled ? (
    <button
        onClick={() => {
            console.log("Continue clicked");
            console.log("Course ID:", course._id);
            navigate(`/courses/${course._id}/learn`);
        }}
        className="w-full rounded-lg bg-green-600 px-4 py-3 font-medium text-white hover:bg-green-700"
    >
        Continue Learning
    </button>

                                        ) : (
                                            <button
                                                onClick={() =>
                                                    handleEnroll(
                                                        course._id
                                                    )
                                                }
                                                className="w-full rounded-lg bg-blue-600 px-4 py-3 font-medium text-white transition hover:bg-blue-700"
                                            >
                                                Enroll Now
                                            </button>
                                        )}

                                    </div>
                                </div>
                            );
                        })}

                    </div>
                )}

            </div>
        </div>
    );
};

export default Courses;