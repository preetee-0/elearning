import { useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import { FiBookOpen, FiMail, FiLock } from "react-icons/fi";

export default function Login() {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const navigate=useNavigate();
  const handleLogin=async e=>{e.preventDefault();try{const r=await axios.post(`${import.meta.env.VITE_API_URL}/users/login`,{email,password});localStorage.setItem("token",r.data.token);localStorage.setItem("user",JSON.stringify(r.data.user));navigate(r.data.user?.role==="instructor"?"/instructor/dashboard":"/student/dashboard")}catch(err){alert(err.response?.data?.message||"Login failed")}};
  return <div className="auth-page"><div className="auth-card"><div className="auth-logo"><FiBookOpen/></div><span className="eyebrow">WELCOME BACK</span><h1>Sign in to learn</h1><p>Continue your learning journey with E-Learning.</p><form onSubmit={handleLogin}><label>Email<div className="input-wrap"><FiMail/><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Enter your email" required/></div></label><label>Password<div className="input-wrap"><FiLock/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter your password" required/></div></label><button className="btn btn-primary full" type="submit">Sign In</button></form><div className="auth-footer">Don't have an account? <Link to="/register">Create one</Link></div></div></div>
}
